﻿#######
#
<#

Import-Module .\Add-OmsWorkspace.psm1 -Force

Import-Module \\crom\C$\Users\<Your username>\Source\Repos\PowerShell\Add-OmsWorkspace.psm1 -Force


$primaryWorkspaceID = '7388eb86-8c68-4d19-ae90-18e9a8235d5d'
$primaryWorkspaceKey = '<supa secret keys>'
$secondaryWorkspaceID = '0f00ef94-f80f-4165-81d6-f417b8000a15'
$secondaryWorkspaceKey = '<supa secret keys>'
$VerbosePreference = 'Continue'

Set-OMSWorkspaces $primaryWorkspaceID $primaryWorkspaceKey
Set-OMSWorkspaces $primaryWorkspaceID $primaryWorkspaceKey $secondaryWorkspaceID $secondaryWorkspaceKey
Set-OMSWorkspaces $null $null $secondaryWorkspaceID $secondaryWorkspaceKey
Set-OMSWorkspaces $null $null $null $null



Test-OMSWorkspaces $primaryWorkspaceID $null
Test-OMSWorkspaces $primaryWorkspaceID $secondaryWorkspaceID 
Test-OMSWorkspaces $null  $secondaryWorkspaceID
Test-OMSWorkspaces $null $null 


testing stuff
$healthService.RemoveCloudWorkspace($primaryWorkspaceID)
$healthService.RemoveCloudWorkspace($secondaryWorkspaceID)
$healthService.ReloadConfiguration();$healthService = $null;$healthService = New-Object -ComObject 'AgentConfigManager.MgmtSvcCfg'


#>
function Test-OMSWorkspaces {
	param(
		[string] $primaryWorkspaceID,
		[string] $secondaryWorkspaceID
	    )
	$returnedStatus = $true
	# bail out quick if the customer doesn't want monitoring
	if(!$primaryWorkspaceID -and !$secondaryWorkspaceID){write-verbose "Customer doen't want monitoring";return $true}
	$service = Get-Service -Name "HealthService" -ErrorAction SilentlyContinue
	if(!$service -and $returnedStatus){
		Write-Verbose "Microsoft Monitoring Agent service not installed.`r`nTEST:FAILED"
		$returnedStatus = $false
	}
	else {Write-Verbose "Microsoft Monitoring Agent service is installed."}
	if($service.Status -ne "Running" -and $returnedStatus){
		Write-Verbose "Microsoft Monitoring Agent service is not running.`r`nTEST:FAILED"
		$returnedStatus = $false
	}
	elseif($returnedStatus) {Write-Verbose "Microsoft Monitoring Agent service is running."}
	if($returnedStatus){
		if($primaryWorkspaceID){
			try{
				$healthService = New-Object -ComObject 'AgentConfigManager.MgmtSvcCfg'
				if($($healthService.GetCloudWorkspace($primaryWorkspaceID)) -eq $null){
					Write-Verbose "Primary workspace is NOT present.`r`nTEST:FAILED"
					$returnedStatus = $false
				} 
				else {Write-Verbose "Primary workspace is present."}
			}
			catch{
				Write-Verbose "Error checking the primary workspace:$($_.Exception.Message)`r`nTEST:FAILED"
				$returnedStatus = $false
			}
		}
		if($secondaryWorkspaceID){
			try{
				if(!$healthService){$healthService = New-Object -ComObject 'AgentConfigManager.MgmtSvcCfg'}
				if($($healthService.GetCloudWorkspace($secondaryWorkspaceID)) -eq $null){
					Write-Verbose "Secondary workspace is NOT present.`r`nTEST:FAILED"
					$returnedStatus = $false
				} else {Write-Verbose "Secondary workspace is already present."}
			}
			catch{
				Write-Verbose "Error configuring the secondary workspace:$($_.Exception.Message)`r`nTEST:FAILED"
				$returnedStatus = $false
			}
		}
	}
	return $returnedStatus
}

function Download-File
{
    param(
        [string] $urlToDownload,
        [string[]] $FolderPath,
		[string] $FileName,
        [int] $maxAttempts = 3,
		[switch] $verbose
		)
    if($verbose)
    {
        $VerbosePreference = "continue"
    }

    #create the folder if not exist
    if(!(Test-Path $FolderPath))
    {
        New-Item -ItemType Directory -Path $FolderPath -Force
    }

    $filePath = "$FolderPath\$FileName"
    
    $attemptSeq=0
    while (!(Test-Path $filePath) -and ($attemptSeq -lt $maxAttempts))
    {
        try
        {
            Write-Verbose -Message "Downloading file(attempt:$attemptSeq) from $urlToDownload to $FolderPath...."
			wget -Uri $urlToDownload -OutFile "$FolderPath\$FileName" 
        }
        catch
        {
            Write-Verbose "Exception occured while downloading in attempt:$attemptSeq . Exp->$_.Exception.Message"

            $errorMsg = "$errorMsg ; Attempt:$attemptSeq -> $_.Exception.Message"
        }
        Write-Verbose "sleeping for 2 seconds"
        sleep 2
        $attemptSeq = $attemptSeq + 1
    }
    if(Test-Path $FolderPath)
    {
        return $true
    }
    else
    {
        throw "Error occured while downloading the file. Exp->$errorMsg"
    }
}

function Install-OMSAgent
{
    param(
        [string] $exeFilePath,
        [string[]] $argsList,
		[string] $maxmntsTowait,
		[string] $serviceName,
        [string] $agentDownloadURL = "http://download.microsoft.com/download/3/1/7/317DCEEB-5E48-47B0-A849-D8A2B1D7795C/MMASetup-AMD64.exe",
        [switch] $verbose
		)
    if($verbose)
    {
        $VerbosePreference = "continue"
    }

    #download the OMSAgent set up file
    if((Download-File -urlToDownload $agentDownloadURL `
        -FolderPath "C:\temp\oms"`
        -FileName "MMASetup-AMD64.exe" `
        -maxAttempts 3 `
        -verbose) -eq $false)
    {
        throw "Exception occured while downloading file in the method."
    }
    
    #wait for 30 seconds before starting the installation process...
    Write-Verbose "wait for 30 seconds before starting the installation process..."
    sleep(30)
    #now install the MMA
    $maxAttempts = 3
    $attemptSeq =0
    $installStatus = $false
    while(($attemptSeq -lt $maxAttempts) -and ($installStatus -eq $false))
    {
        #install the setvice 
        Write-Verbose "Invoking the setup file($exeFilePath) to install OMSAgent. Attempt - $attemptSeq"
        $processObj = Start-Process -FilePath $exeFilePath -ArgumentList $argsList -Wait -PassThru
        Write-Verbose "The setup($exeFilePath) exited with exit code - $($processObj.ExitCode) in the attempt no $attemptSeq"
        
        #get service object to verify if the setup did its job or not
        $service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
        if($service -ne $null)
        {
            $installStatus = $true
        }
        else
        {
            $attemptSeq = $attemptSeq + 1
            Write-Verbose "Sleep for 10 seconds before installation begins..."
            sleep(10)
        
        }
    }
    if($installStatus -eq $false)
    {
        Write-Verbose "OMS agent installation failed for 3 attempts. So exiting with failure"
        throw "OMS agent installation failed for 3 attempts. So exiting with failure"
    }

    #OMS agent setup executed successfully. 
    Write-Verbose "OMS agent installed successfully with exit code - $($processObj.ExitCode)"

    $processStatus = $false
    $StartDate = Get-Date
    while ((NEW-TIMESPAN -Start $StartDate -End (Get-Date)).Minutes -lt $maxmntsTowait)
    {
        $currTime = Get-Date
        #check the health service status
        $service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
        if($service -ne $null)
        {
            if($service.Status -eq [System.ServiceProcess.ServiceControllerStatus]::Running)
            {
                Write-Verbose "Status of health service is $($service.Status.ToString()). Now exiting the loop"
                $processStatus = $true
                break
            }
            elseif($service.Status -eq [System.ServiceProcess.ServiceControllerStatus]::Stopped)
            {
                Start-Service -Name "HealthService"
            }
            $srvStatus = $service.Status
            Write-Verbose "Status of health service is $srvStatus"
        }
        else
        {
            #service not found which is strage. wait for 5seconds
            Write-Verbose "Service object is null. What to do now?? Lets wait for the maximum time if it comes up"
        }

        #wait for 5 seconds
        Write-Verbose "Sleeping for 5 seconds."
        sleep 5
    }

    if ($processStatus -eq $false)
    {
        throw "The service installed successfully. But still the object is coming null from past 5mnts"
    }
    return $processStatus
}

function Set-OMSWorkspaces {
	param(
		[string] $primaryWorkspaceID,
		[string] $primaryWorkspaceKey,
		[string] $secondaryWorkspaceID,
		[string] $secondaryWorkspaceKey
	    )
	if(!$primaryWorkspaceID -and !$secondaryWorkspaceID){
		Write-Verbose -Message "Customer doen't want monitoring. Doing nothing..."
	}
	else{
		if(!(Test-Path "C:\temp\oms\MMASetup-AMD64.exe")){
			Write-Verbose -Message "Downloading latest OMS agent..."
			New-Item -ItemType Directory -Path "C:\temp\oms" -Force -ErrorAction SilentlyContinue | Out-Null
			wget -Uri "http://download.microsoft.com/download/3/1/7/317DCEEB-5E48-47B0-A849-D8A2B1D7795C/MMASetup-AMD64.exe" -OutFile "C:\temp\oms\MMASetup-AMD64.exe" 
		}

        #install the OMS agent
        $installStatus = Install-OMSAgent -exeFilePath "C:\Temp\oms\MMASetup-AMD64.exe" `
                            -argsList "/Q:A /R:N /C:`"setup.exe /qn AcceptEndUserLicenseAgreement=1 NOAPM=1`"" `
                            -maxmntsTowait 5 `
                            -serviceName "HealthService" `
                            -verbose
        
        if(!$installStatus)
        {
            Write-Verbose "Unable to set up the OMS agent and quitting the process"
            throw "Unable to setup the OMS agent"
        }
        else
		{
            #OMS agent is running successfully. 

        	#if primary stuff is null skip this try statement
			if($primaryWorkspaceID){
				try{
					$healthService = New-Object -ComObject 'AgentConfigManager.MgmtSvcCfg'
					if($($healthService.GetCloudWorkspace($primaryWorkspaceID)) -eq $null){
						Write-Verbose "Adding the primary workspace to the configuration and reloading the config."
						$healthService.AddCloudWorkspace($primaryWorkspaceID,$primaryWorkspaceKey)
						$healthService.ReloadConfiguration()
						sleep 30
						$healthService = $null
						$healthService = New-Object -ComObject 'AgentConfigManager.MgmtSvcCfg'
					} else {Write-Verbose "primary workspace is already present."}
				}
				catch{
					Write-Verbose "Error configuring the primary workspace:$($_.Exception.Message)"
				}
			}

			# initialize the health service
			if($secondaryWorkspaceID){
				try{
					if(!$healthService){$healthService = New-Object -ComObject 'AgentConfigManager.MgmtSvcCfg'}
					if($($healthService.GetCloudWorkspace($secondaryWorkspaceID)) -eq $null){
						Write-Verbose "Adding the secondary workspace to the configuration and reloading the config."
						$healthService.AddCloudWorkspace($secondaryWorkspaceID,$secondaryWorkspaceKey)
						$healthService.ReloadConfiguration()
						sleep 30
						$healthService = $null
						$healthService = New-Object -ComObject 'AgentConfigManager.MgmtSvcCfg'
					} else {Write-Verbose "Secondary workspace is already present."}
				}
				catch{
					Write-Verbose "Error configuring the secondary workspace:$($_.Exception.Message)"
				}
			}
			foreach($workspace in $($healthService.GetCloudWorkspaces())){
				Write-Verbose "$($workspace.workspaceId) is configured on the agent with a status of:$($workspace.ConnectionStatusText)"
			}
		}
	}
}
export-modulemember -function Test-OMSWorkspaces,Set-OMSWorkspaces,Download-File